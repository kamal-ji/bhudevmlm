<div class="footer d-sm-flex align-items-center justify-content-between bg-white py-2 px-4 border-top">
				<p class="text-dark mb-0">&copy; {{ date('Y') }} <a href="javascript:void(0);" class="link-primary">Tiara</a>, All Rights Reserved</p>
				<p class="text-dark">Version : 1.3.8</p>
			</div>